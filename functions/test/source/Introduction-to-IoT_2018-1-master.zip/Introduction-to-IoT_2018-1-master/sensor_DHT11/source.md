Original source files (README.md, dht11.py, dht11_example.py) in this directory are obtained from
https://github.com/szazo/DHT11_Python

dht11_example.py (an example code to use a DHT11 sensor and dht11.py library) has been modified by skang-koreatech
 
