# -*- coding:utf-8 -*-
print("Hello World!!!")
print("파이썬은 재미있습니다.")
